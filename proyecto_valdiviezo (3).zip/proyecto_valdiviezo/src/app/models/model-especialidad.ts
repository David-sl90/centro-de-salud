export interface Especialidad {
    id_especialidad?: number;
    nombre_especialidad: string;
    descripcion: string;
}