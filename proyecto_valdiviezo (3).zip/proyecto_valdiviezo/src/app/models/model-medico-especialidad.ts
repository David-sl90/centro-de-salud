export interface MedicoEspecialidad {
    id_medico?: number;
    nombre_medico: string;
    apellido_medico: string;
    cmp: string;
    nombre_especialidad: string;
    descripcion: string;
}