export interface paciente {
    idPaciente?: number,
    nombres: string,
    apellidos: string,
    dni: string,
    fecha_nacimiento: string,
    sexo: string,
    id_estado_paciente: number,
    id_ubigeo: number
}