import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { paciente } from '../../../models/model-paciente';
import { appsettings } from '../../../config/appsettings';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ServicePaciente {
  private http = inject(HttpClient);
  private urlService = appsettings.apiUrl + 'api/paciente';

  constructor() { }

  // 🔑 Método para armar headers con token
  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('token');
    return new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
  }

  listarPacientes(): Observable<paciente[]> {
    return this.http.get<paciente[]>(this.urlService, {
      headers: this.getAuthHeaders(),
    });
  }

  crearPaciente(obj: paciente): Observable<paciente> {
    return this.http.post<paciente>(this.urlService + '/crear', obj, {
      headers: this.getAuthHeaders(),
    });
  }

  obtenerPaciente(id: number): Observable<paciente> {
    return this.http.get<paciente>(`${this.urlService}/codigo/${id}`, {
      headers: this.getAuthHeaders(),
    });
  }

  actualizarPaciente(obj: paciente, id: number): Observable<paciente> {
    return this.http.put<paciente>(`${this.urlService}/actualizar/${id}`, obj, {
      headers: this.getAuthHeaders(),
    });
  }

  eliminarPaciente(id: number): Observable<void> {
    return this.http.delete<void>(`${this.urlService}/eliminar/${id}`, {
      headers: this.getAuthHeaders(),
    });
  }
}