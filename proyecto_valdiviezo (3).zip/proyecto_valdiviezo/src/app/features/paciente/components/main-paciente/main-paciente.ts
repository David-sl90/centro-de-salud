import { Component, inject } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ServicePaciente } from '../../services/service-paciente';
import { paciente } from '../../../../models/model-paciente';
import { DetallePaciente } from '../detalle-paciente/detalle-paciente';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-main-paciente',
  imports: [CommonModule],
  templateUrl: './main-paciente.html',
  styleUrl: './main-paciente.css',
})
export class MainPaciente {
  public listapacientes: paciente[] = [];
  private pacienteservice = inject(ServicePaciente);

  constructor(private router: Router, private modalService: NgbModal) {
    this.listar();
  }

  listar() {
    this.pacienteservice.listarPacientes().subscribe({
      next: (data) => {
        this.listapacientes = data;
        console.log(this.listapacientes);
      },
      error: (err) => {
        console.error('Error al recuperar registros de pacientes.', err);
        if (err.status === 403) {
          alert('Acceso denegado. Inicie sesión nuevamente.');
          this.router.navigate(['/login']);
        }
      },
    });
  }



  nuevo() {
    const modalRef = this.modalService.open(DetallePaciente);
    modalRef.componentInstance.id = 0;
  }

  editar(obj: paciente) {
    const modalRef = this.modalService.open(DetallePaciente);
    modalRef.componentInstance.id = obj.idPaciente;
  }

  eliminar(obj: paciente) {
    const id = obj.idPaciente;
    if (id == null) {
      console.error("Eliminar: paciente.id_paciente no encontrado")
      return;
    }
    this.pacienteservice.eliminarPaciente(id).subscribe(() => {
      this.listar();
    });
  }
}
