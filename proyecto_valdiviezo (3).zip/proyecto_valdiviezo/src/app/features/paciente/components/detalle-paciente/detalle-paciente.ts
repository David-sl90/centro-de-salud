import { CommonModule } from '@angular/common';
import { Component, inject, Input } from '@angular/core';
import { ServicePaciente } from '../../services/service-paciente';
import { Router } from '@angular/router';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { paciente } from '../../../../models/model-paciente';

@Component({
  selector: 'app-detalle-paciente',
  imports: [CommonModule],
  templateUrl: './detalle-paciente.html',
  styleUrl: './detalle-paciente.css',
})
export class DetallePaciente {
  @Input('id') id!: number
  private pacienteservice = inject(ServicePaciente)

  constructor(public router: Router, private activeModal: NgbActiveModal) {

  }

  ngOnInit(): void {
    if (this.id != 0) {
      this.obtener(this.id);
    }
  }

  cerrar() {
    this.activeModal.close('');
  }

  guardar() {
    const nombres = String($('#txt_nombres').val()).trim();
    const apellidos = String($('#txt_apellidos').val()).trim();
    const dni = String($('#txt_dni').val()).trim();
    const fecha_nacimiento = String($('#txt_fecha_nacimiento').val()).trim();
    const sexo = String($('#txt_sexo').val()).trim().toUpperCase();
    const id_estado_paciente = Number($('#txt_id_estado_paciente').val());
    const id_ubigeo = Number($('#txt_ubigeo').val());

    const soloLetras = /^[a-zA-ZÁÉÍÓÚáéíóúñÑ ]+$/;
    const dniRegex = /^[0-9]{8}$/;
    const fechaRegex = /^\d{4}-\d{2}-\d{2}$/;
    const sexoRegex = /^[MF]$/;

    if (!nombres || !soloLetras.test(nombres)) {
      alert("El nombre solo puede contener letras.");
      return;
    }

    if (!apellidos || !soloLetras.test(apellidos)) {
      alert("El apellido solo puede contener letras.");
      return;
    }

    if (!dniRegex.test(dni)) {
      alert("El DNI debe contener exactamente 8 dígitos numéricos.");
      return;
    }

    if (!fechaRegex.test(fecha_nacimiento)) {
      alert("La fecha de nacimiento debe tener el formato aaaa-mm-dd.");
      return;
    }

    if (!sexoRegex.test(sexo)) {
      alert("El sexo debe ser 'M' (Masculino) o 'F' (Femenino).");
      return;
    }

    if (isNaN(id_estado_paciente) || id_estado_paciente <= 0) {
      alert("Debe ingresar un ID de estado válido.");
      return;
    }

    if (isNaN(id_ubigeo) || id_ubigeo <= 0) {
      alert("Debe ingresar un ID de ubigeo válido.");
      return;
    }

    const obj: paciente = {
      nombres,
      apellidos,
      dni,
      fecha_nacimiento,
      sexo,
      id_estado_paciente,
      id_ubigeo
    };

    if (this.id === 0) {
      this.pacienteservice.crearPaciente(obj).subscribe({
        next: () => this.cerrar()
      });
    } else {
      this.pacienteservice.actualizarPaciente(obj, this.id).subscribe({
        next: () => this.cerrar()
      });
    }
  }



  obtener(id: number) {
    this.pacienteservice.obtenerPaciente(id).subscribe({
      next: (data) => {
        $("#txt_nombres").val(data.nombres);
        $("#txt_apellidos").val(data.apellidos);
        $("#txt_dni").val(data.dni);
        $("#txt_fecha_nacimiento").val(data.fecha_nacimiento);
        $("#txt_sexo").val(data.sexo);
        $("#txt_id_estado_paciente").val(data.id_estado_paciente);
        $("#txt_ubigeo").val(data.id_ubigeo);
      },
    });
  }
}
