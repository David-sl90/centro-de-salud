import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { appsettings } from '../../../config/appsettings';
import { medico } from '../../../models/model-medico';
import { Observable } from 'rxjs';
import { MedicoEspecialidad } from '../../../models/model-medico-especialidad';
import { Especialidad } from '../../../models/model-especialidad';

@Injectable({
  providedIn: 'root',
})
export class ServiceMedico {
  private http = inject(HttpClient);
  private urlservice = appsettings.apiUrl + 'api/medico';
  private urlespecialidad = appsettings.apiUrl + 'api/especialidad';

  constructor() { }

  // 🔑 Método para armar headers con token
  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('token');
    return new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
  }

  // Listar médicos
  listarmedicos(): Observable<medico[]> {
    return this.http.get<medico[]>(this.urlservice, {
      headers: this.getAuthHeaders(),
    });
  }

  // Crear nuevo médico
  crear(objeto: medico): Observable<medico> {
    return this.http.post<medico>(this.urlservice + '/crear', objeto, {
      headers: this.getAuthHeaders(),
    });
  }

  // Obtener médico por ID
  obtener(id: number): Observable<medico> {
    return this.http.get<medico>(`${this.urlservice}/codigo/${id}`, {
      headers: this.getAuthHeaders(),
    });
  }

  // Actualizar médico
  actualizar(obj: medico, id: number): Observable<medico> {
    return this.http.put<medico>(`${this.urlservice}/actualizar/${id}`, obj, {
      headers: this.getAuthHeaders(),
    });
  }

  // Eliminar médico
  eliminar(id: number): Observable<void> {
    return this.http.delete<void>(`${this.urlservice}/eliminar/${id}`, {
      headers: this.getAuthHeaders(),
    });
  }

  // Listar médicos con especialidad
  getMedicosConEspecialidad(): Observable<MedicoEspecialidad[]> {
    return this.http.get<MedicoEspecialidad[]>(
      `${this.urlservice}/conEspecialidad`,
      { headers: this.getAuthHeaders() }
    );
  }

  // Listar especialidades
  getEspecialidades(): Observable<Especialidad[]> {
    return this.http.get<Especialidad[]>(`${this.urlespecialidad}/especialidad`, {
      headers: this.getAuthHeaders(),
    });
  }
}