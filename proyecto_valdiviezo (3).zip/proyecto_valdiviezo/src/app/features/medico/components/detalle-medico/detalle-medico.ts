import { Component, inject, Input } from '@angular/core';
import { ServiceMedico } from '../../services/service-medico';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { medico } from '../../../../models/model-medico';
import $ from 'jquery';
import { Especialidad } from '../../../../models/model-especialidad';

@Component({
  selector: 'app-detalle-medico',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './detalle-medico.html',
  styleUrls: ['./detalle-medico.css']
})
export class DetalleMedico {
  @Input('id') id!: number
  public especialidades: Especialidad[] = [];
  private medicoservice = inject(ServiceMedico);

  constructor(public router: Router, private activeModal: NgbActiveModal) {

  }

  ngOnInit(): void {
    this.medicoservice.getEspecialidades().subscribe({
      next: (data) => {
        this.especialidades = data;
      }
    });

    if (this.id != 0) {
      this.obtener(this.id);
    }
  }

  cerrar() {
    this.activeModal.close('');
  }

  guardar() {
    const nombres = String($('#txt_nombres').val()).trim();
    const apellidos = String($('#txt_apellidos').val()).trim();
    const cmp = String($('#txt_cmp').val()).trim();
    const id_especialidad = Number($('#combo_especialidad').val());

    // Validaciones
    const soloLetras = /^[a-zA-ZÁÉÍÓÚáéíóúñÑ ]+$/;
    const soloNumeros = /^[0-9]{4,10}$/;

    if (!nombres || !soloLetras.test(nombres)) {
      alert("El nombre solo puede contener letras.");
      return;
    }
    if (!apellidos || !soloLetras.test(apellidos)) {
      alert("El apellido solo puede contener letras.");
      return;
    }
    if (!cmp || !soloNumeros.test(cmp)) {
      alert("El CMP debe ser numérico y tener entre 4 y 10 dígitos.");
      return;
    }
    if (!id_especialidad || id_especialidad === 0) {
      alert("Debe seleccionar una especialidad.");
      return;
    }

    const obj: medico = {
      nombres,
      apellidos,
      cmp,
      id_especialidad
    };

    if (this.id === 0) {
      this.medicoservice.crear(obj).subscribe({
        next: () => this.cerrar()
      });
    } else {
      this.medicoservice.actualizar(obj, this.id).subscribe({
        next: () => this.cerrar()
      });
    }
  }



  obtener(id: number) {
    this.medicoservice.obtener(id).subscribe({
      next: (data) => {
        $("#txt_nombres").val(data.nombres);
        $("#txt_apellidos").val(data.apellidos);
        $("#txt_cmp").val(data.cmp);
        $("#combo_especialidad").val(data.id_especialidad);
      },
    });
  }

}
