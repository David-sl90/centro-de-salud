import { Component } from "@angular/core";
import { Router, RouterModule } from "@angular/router";
import { NgbModal, NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { CommonModule } from "@angular/common";

import { ServiceMedico } from "../../services/service-medico";
import { DetalleMedico } from "../detalle-medico/detalle-medico";
import { MedicoEspecialidad } from "../../../../models/model-medico-especialidad";

@Component({
  selector: 'app-main-medico',
  standalone: true,
  imports: [CommonModule, RouterModule, NgbModule],
  templateUrl: './main-medico.html',
  styleUrls: ['./main-medico.css']
})
export class MainMedico {
  public listamedicos: MedicoEspecialidad[] = [];

  // 🔑 Inyecta el servicio en el constructor
  constructor(
    private router: Router,
    private modalService: NgbModal,
    private medicoservice: ServiceMedico
  ) {
    this.listar();
  }

  listar() {
    this.medicoservice.getMedicosConEspecialidad().subscribe({
      next: (data: MedicoEspecialidad[]) => {
        this.listamedicos = data;
        console.log('Lista de médicos:', this.listamedicos);
      },
      error: (err) => {
        console.error('Error al recuperar registros. Verifica el token o permisos.', err);
        if (err.status === 403) {
          alert('Acceso denegado. Inicie sesión nuevamente.');
          this.router.navigate(['/login']);
        }
      }
    });
  }

  nuevo() {
    const modalRef = this.modalService.open(DetalleMedico);
    modalRef.componentInstance.id = 0;
    modalRef.closed.subscribe(() => this.listar());
  }

  editar(obj: MedicoEspecialidad) {
    const modalRef = this.modalService.open(DetalleMedico);
    modalRef.componentInstance.id = obj.id_medico;
    modalRef.closed.subscribe(() => this.listar());
  }

  eliminar(obj: MedicoEspecialidad) {
    const id = obj.id_medico;
    if (!id) {
      console.error('Eliminar: medico.id_medico no encontrado');
      return;
    }
    if (confirm(`Seguro que deseas eliminar al medico ${obj.nombre_medico} ${obj.apellido_medico}?`)) {
      this.medicoservice.eliminar(id).subscribe({
        next: () => {
          console.log('Medico eliminado correctamente');
          this.listar();
        },
        error: (err) => {
          console.error('Error al eliminar medico', err);
          if (err.status === 403) {
            alert('Acceso denegado. Inicie sesión nuevamente.');
            this.router.navigate(['/login']);
          }
        }
      });
    }
  }
}