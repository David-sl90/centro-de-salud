import { Component } from '@angular/core';

@Component({
  selector: 'app-cita',
  imports: [],
  templateUrl: './cita.html',
  styleUrl: './cita.css',
})
export class Cita {

}
