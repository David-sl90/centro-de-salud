import { Component } from '@angular/core';

@Component({
  selector: 'app-main-cita',
  imports: [],
  templateUrl: './main-cita.html',
  styleUrl: './main-cita.css',
})
export class MainCita {

}
