import { Routes } from '@angular/router';

export const routes: Routes = [
    {
        path: 'login',
        loadComponent: () =>
            import('./login/login')
                .then(m => m.LoginComponent)
    },

    {
        path: 'medico',
        loadComponent: () =>
            import('./features/medico/components/main-medico/main-medico')
                .then(m => m.MainMedico)
    },
    {
        path: 'paciente',
        loadComponent: () =>
            import('./features/paciente/components/main-paciente/main-paciente')
                .then(m => m.MainPaciente)
    },
    {
        path: '',
        redirectTo: 'login',
        pathMatch: 'full'
    }

];
