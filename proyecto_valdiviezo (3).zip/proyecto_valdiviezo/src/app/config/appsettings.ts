export const appsettings = {
    apiUrl: "http://localhost:8080/"
}