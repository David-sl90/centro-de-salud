package com.centro_valdiviezo.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CentroValdiviezoApplicationTests {

	@Test
	void contextLoads() {
	}

}
