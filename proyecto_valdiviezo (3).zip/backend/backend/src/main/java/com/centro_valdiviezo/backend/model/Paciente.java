package com.centro_valdiviezo.backend.model;

import jakarta.persistence.*;

@Entity
@Table(name = "Paciente")
public class Paciente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_paciente")
    private Integer idPaciente;
    private String nombres;
    private String apellidos;
    private String dni;
    private String fecha_nacimiento;
    private String sexo;
    private Integer id_estado_paciente;
    private Integer id_ubigeo;

    public Integer getIdPaciente() {
        return idPaciente;
    }

    public void setIdPaciente(Integer idPaciente) {
        this.idPaciente = idPaciente;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getFecha_nacimiento() {
        return fecha_nacimiento;
    }

    public void setFecha_nacimiento(String fecha_nacimiento) {
        this.fecha_nacimiento = fecha_nacimiento;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public Integer getId_estado_paciente() {
        return id_estado_paciente;
    }

    public void setId_estado_paciente(Integer id_estado_paciente) {
        this.id_estado_paciente = id_estado_paciente;
    }

    public Integer getId_ubigeo() {
        return id_ubigeo;
    }

    public void setId_ubigeo(Integer id_ubigeo) {
        this.id_ubigeo = id_ubigeo;
    }
}
