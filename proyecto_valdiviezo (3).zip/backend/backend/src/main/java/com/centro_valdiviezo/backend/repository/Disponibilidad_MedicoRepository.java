package com.centro_valdiviezo.backend.repository;

import com.centro_valdiviezo.backend.model.Disponibilidad_Medico;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface Disponibilidad_MedicoRepository extends JpaRepository<Disponibilidad_Medico, Integer> {
}
