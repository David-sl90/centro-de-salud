package com.centro_valdiviezo.backend.seguridad;

import java.util.Collection;
import java.util.Collections;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.centro_valdiviezo.backend.model.UsuarioModel;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class UserDetailsImpl implements UserDetails {
    private final UsuarioModel usr;

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {

        return Collections.singletonList(() -> "ROLE_USER");

    }

    @Override
    public String getPassword() {
        // TODO Auto-generated method stub
        return usr.getClave();
    }

    @Override
    public String getUsername() {
        // TODO Auto-generated method stub
        return usr.getCorreo();
    }

    public String getNombre() {
        return usr.getNombre();
    }

}
