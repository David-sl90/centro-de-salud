package com.centro_valdiviezo.backend.controller;

import com.centro_valdiviezo.backend.model.Cita;
import com.centro_valdiviezo.backend.repository.CitaRepository;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/cita")
@CrossOrigin(origins = "*")
public class CitaController {

    private final CitaRepository repository;

    public CitaController(CitaRepository repository) {
        this.repository = repository;
    }

    @GetMapping
    public List<Cita> obtenerTodos() {
        return repository.findAll();
    }

    @PostMapping
    public Cita crear(@RequestBody Cita item) {
        return repository.save(item);
    }

    @GetMapping("/{id}")
    public Cita obtenerPorId(@PathVariable Integer id) {
        return repository.findById(id).orElse(null);
    }

    @PutMapping("/{id}")
    public Cita actualizar(@PathVariable Integer id, @RequestBody Cita nuevo) {
        return repository.findById(id)
                .map(e -> {
                    e.setId_paciente(nuevo.getId_paciente());
                    e.setId_medico(nuevo.getId_medico());
                    e.setFecha_cita(nuevo.getFecha_cita());
                    e.setHora_cita(nuevo.getHora_cita());
                    e.setMotivo(nuevo.getMotivo());
                    e.setEstado_cita(nuevo.getEstado_cita());
                    return repository.save(e);
                })
                .orElse(null);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Integer id) {
        repository.deleteById(id);
    }
}
