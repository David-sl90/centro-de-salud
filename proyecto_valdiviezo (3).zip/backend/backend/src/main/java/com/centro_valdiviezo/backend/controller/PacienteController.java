package com.centro_valdiviezo.backend.controller;

import com.centro_valdiviezo.backend.model.Paciente;
import com.centro_valdiviezo.backend.services.PacienteService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Optional;

@RestController
@RequestMapping("/api/paciente")
@CrossOrigin(origins = "*")
public class PacienteController {

    @Autowired
    PacienteService pacienteService;

    @GetMapping
    public ArrayList<Paciente> listar() {
        return this.pacienteService.listarPacientes();
    }

    @GetMapping(path = "/codigo/{id}")
    public Optional<Paciente> obtenerPacienteId(@PathVariable("id") Integer id) {
        return this.pacienteService.listarPorId(id);
    }

    @PostMapping(path = "/crear")
    public Paciente crear(@RequestBody Paciente paciente) {
        return this.pacienteService.crearPaciente(paciente);
    }

    @PutMapping("/actualizar/{id}")
    public Paciente actualizarPaciente(@RequestBody Paciente paciente, @PathVariable Integer id) {
        return this.pacienteService.actualizarPaciente(paciente, id);
    }

    @DeleteMapping("/eliminar/{id}")
    public String eliminarPaciente(@PathVariable("id") Integer id) {
        this.pacienteService.eliminarPaciente(id);
        return "success";
    }
}
